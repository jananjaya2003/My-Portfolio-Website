
  # Animated 3D Portfolio Website

  This is a code bundle for Animated 3D Portfolio Website. The original project is available at https://www.figma.com/design/E61DHymNGNRMW4qKA5j3mu/Animated-3D-Portfolio-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  